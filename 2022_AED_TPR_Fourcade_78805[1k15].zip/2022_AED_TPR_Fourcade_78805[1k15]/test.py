import os.path
import pickle
from registro import *


def menu():
    print('\n===Menu===')
    print('1) Cargar vector de generos.')
    print('2) Cargar vector de registros.')
    print('3) Mostrar Series con duracion entre a y b.')
    print('4) Generar vector de conteo.')
    print('5) Generar Archivo Binario.')
    print('6) Mostrar archivo Binario.')
    print('7) Buscar Serie.')
    print('0) Salir.')


def leer_generos(fd):
    v = []
    if os.path.exists(fd):
        m = open(fd, 'r')
        lines = m.readlines()
        for line in lines:
            if line.endswith('\n'):
                line = line[:-1]
                v.append(line)
        m.close()
        return v
    else:
        print('El archivo no existe.')


def obtener_cod_genero(cad, v):
    for i in range(len(v)):
        if cad == v[i]:
            return i


def generar_registros(fd, v):
    if not os.path.exists(fd):
        print('El archivo no existe...')
        return
    registros = []
    nro_linea = 0
    m = open(fd, mode="rt", encoding="utf8")
    for linea in m:
        #cuanto la 1era linea
        nro_linea += 1
        #Si es la primera linea salteo
        if nro_linea == 1:
            continue
        #Guardo la linea de texto sin el salto de linea
        if linea[-1] == '\n':
            linea = linea[:-1]
        #divido la linea y obtengo cada campo
        campos = linea.split('|')
        poster = campos[0]
        title = campos[1]
        run_s = campos[2]
        cert = campos[3]
        run_e = campos[4]
        if run_e == '':
            continue
        run_e = run_e[:-4]
        genre = obtener_cod_genero(campos[5], v)
        rating = campos[6]
        over = campos[7]
        votes = campos[12]
        reg = Registro(poster, title, run_s, cert, int(run_e), genre, rating, over, int(votes))

        add_in_order(registros, reg)
    m.close()
    return registros


def add_in_order(v, reg):
    pos = 0
    izq, der = 0, len(v) - 1
    while izq <= der:
        c = (izq + der) // 2
        if v[c].nro_votes == reg.nro_votes:
            pos = c
            break
        if reg.nro_votes > v[c].nro_votes:
            der = c - 1
        else:
            izq = c + 1
    if izq > der:
        pos = izq
    v[pos:pos] = [reg]


def calcular_prom(contador, acumulador):
    if contador == 0:
        return print('El promedio de minutos es: 0')
    else:
        prom = acumulador / contador
        return print('El promedio de minutos es: ', prom)


def validar_resp():
    resp = int(input('\nDesea guardar los proyectos en un archivo txt ? 1 = si: 2 = no: '))
    while resp < 1 or resp > 2:
        resp = int(input('Respuesta Invalida, recuerde: 1 = si: 2 = no :'))
    return resp


def crear_listado_txt(v):
    fd = 'listado.txt'
    encabezado = 'Poster_Link|Series_Title|Runtime_of_Series|Certificate|Runtime_of_Episodes|Genre|IMDB_Rating|Overview|No_of_Votes\n'
    m = open(fd, 'wt', encoding="utf-8")
    m.write(encabezado)
    for i in range(len(v)):
        r = '{}|{}|{}|{}|{}|{}|{}|{}|{}\n'
        r = r.format(v[i].poster_link, v[i].series_title, v[i].runtime_series, v[i].certificate, v[i].runtime_episodes, v[i].genre, v[i].rating, v[i].overview, v[i].nro_votes)
        m.write(r)
    print('\nListado creado.')
    m.close()


def mostrar_vector(v, a, b):
    cont, acum = 0, 0
    listado = []
    n = len(v)
    for i in range(n):
        if a < v[i].runtime_episodes < b:
            print(v[i])
            cont += 1
            acum += v[i].runtime_episodes
            listado.append(v[i])
    calcular_prom(cont, acum)
    resp = validar_resp()
    if resp == 1:
        crear_listado_txt(listado)
    elif resp == 2:
        print('\nNo se creara el archivo txt.')


def contar_por_genero(series, generos):
    conteo = [0] * len(generos)
    for serie in series:
        conteo[serie.genre] += 1
    return conteo


def mostrar_conteo(v, generos):
    for i in range(len(v)):
        print('Para el genero: ', generos[i], ' Hubo: ', v[i], ' Series.')


def generar_archivo_bin(conteo, generos):
    m = open('Conteo.dat', 'wb')
    for i in range(len(conteo)):
        cont = Conteo(generos[i], i, conteo[i])
        pickle.dump(cont, m)
    m.close()


def mostrar_archivo_bin(fd):
    if os.path.exists(fd):
        m = open(fd, 'rb')
        tam = os.path.getsize(fd)
        while m.tell() < tam:
            reg = pickle.load(m)
            print(reg)
        m.close()


def buscar_por_titulo(series, titulo):
    for i in range(len(series)):
        if series[i].series_title == titulo:
            series[i].nro_votes += 1
            return i
    return -1


def principal():
    op = -1
    fd = 'generos.txt'
    fd2 = 'series_aed.csv'
    fd3 = 'Conteo.dat'
    series = []
    generos = []
    conteo = []
    while op != 0:
        menu()
        op = int(input('Ingrese la Opcion que desee: '))
        if op == 1:
            generos = leer_generos(fd)
            print('\nVector de generos creado con exito.')
        elif op == 2:
            series = generar_registros(fd2, generos)
            print('\nVector de registros generado con exito.')
        elif op == 3:
            a = int(input('Ingrese el limite inferior de min: '))
            b = int(input('Ingrese el limite superior de min: '))
            mostrar_vector(series, a, b)
        elif op == 4:
            conteo = contar_por_genero(series, generos)
            mostrar_conteo(conteo, generos)
        elif op == 5:
            generar_archivo_bin(conteo, generos)
            print('\n Archivo creado con exito.')
        elif op == 6:
            mostrar_archivo_bin(fd3)
        elif op == 7:
            tit = input('Ingrese el titulo a buscar: ')
            ind = buscar_por_titulo(series, tit)
            if ind == -1:
                print('No se encontro el Titulo.')
            else:
                print('Se aumento el nro de votos correctamente. ')
                print(series[ind])
        elif op == 0:
            print('Programa Terminado.')
        else:
            print('Opcion Invalida.')


if __name__ == '__main__':
    principal()
