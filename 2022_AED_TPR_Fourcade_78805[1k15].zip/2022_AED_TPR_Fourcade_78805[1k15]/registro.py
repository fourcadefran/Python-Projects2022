class Registro:
    def __init__(self, poster, title, runtime_s, cert, runtime_ep, genre, rating, over, votes):
        self.poster_link = poster
        self.series_title = title
        self.runtime_series = runtime_s
        self.certificate = cert
        self.runtime_episodes = runtime_ep
        self.genre = genre
        self.rating = rating
        self.overview = over
        self.nro_votes = votes

    def __str__(self):
        r = ''
        r += 'Poster_Link: {}\t - Series_Title: {}\t - Runtime_of_Series: {}\t - Certificate: {}\t - Runtime_of_Episodes {}\t - ' \
             'Genre: {}\t - IMDB_Rating: {}\t - Overview: {}\t - Nro_of_Votes: {}\t'
        r = r.format(self.poster_link, self.series_title, self.runtime_series, self.certificate, self.runtime_episodes, self.genre, self.rating, self. overview, self.nro_votes)
        return r


class Conteo:
    def __init__(self, gen, nro_gen, cant):
        self.genero = gen
        self.nro_gen = nro_gen
        self.cantidad = cant

    def __str__(self):
        r = ''
        r += 'Genero: {}\t - Nro de Genero: {}\t - Cantidad: {}\t'
        r = r.format(self.genero, self.nro_gen, self.cantidad)
        return r


# �
